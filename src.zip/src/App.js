import React, { useEffect, useState } from 'react';
import { Route, BrowserRouter as Router, Routes, useNavigate, useParams } from 'react-router-dom';
import bus from './BUS.png';
import './header.css';
import './Menu.css';
import MenuPage from './MenuPage.js'; // Import the MenuPage component
import NB from './NB.png';// Assuming this is the new CSS file or updated one
import Sitemap from './sitemap.js';
import GoogleVerification from './GoogleVerification.js'; // Import the GoogleVerification component
import { Helmet } from 'react-helmet';



const RestaurantCard = ({ image, address, code, vegnonveg, rating, ratingno, room, onCardClick }) => {
  const navigate = useNavigate();

  const handleCardClick = () => {
    onCardClick(address, code, navigate);
  };

  return (
    <div className="restaurant-card" onClick={handleCardClick}>
      <img className="restaurant-image" src={image} alt="Restaurant" loading="lazy" />
      <div className="restaurant-details">
        <span className="restaurant-address">
          {address}
          <span className={`restaurant-place ${vegnonveg === 'veg' ? 'veg' : 'non-veg'}`}></span>
        </span>
        <div className="container">
          <span className="restaurant-rating">
            <span className="ratingno"></span>
          </span>
        </div>
      </div>
    </div>
  );
};

const App = () => {
  const [restaurants, setRestaurants] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalContent, setModalContent] = useState(null);

  useEffect(() => {
    const fetchRestaurants = async () => {
      try {
        const response = await fetch('https://opensheet.elk.sh/1tj1hdKsm3B_Yv9dAIHBNUqAxEtdVmUNfNVN-YT-9VRE/Sheet1!A1:Z99999');
        if (!response.ok) {
          throw new Error('Failed to fetch data from the API');
        }
        const data = await response.json();
        setRestaurants(data);
      } catch (error) {
        console.error(error);
        // Handle error state if needed
      }
    };

    fetchRestaurants();
  }, []);

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  const performSearch = () => {
    const filteredRestaurants = restaurants.filter(restaurant =>
      restaurant.address.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setSearchResults(filteredRestaurants);
  };

  const displayRestaurants = searchResults !== null ? searchResults : restaurants;

  const uniqueAddresses = new Set();
  const filteredRestaurants = displayRestaurants.filter((restaurant) => {
    if (uniqueAddresses.has(restaurant.address)) {
      return false;
    }
    uniqueAddresses.add(restaurant.address);
    return true;
  });

  const handleCardClick = (address, code, navigate) => {
    const sameAddressRestaurants = restaurants.filter(r => r.address === address);
    if (sameAddressRestaurants.length > 1) {
      setModalContent({ restaurants: sameAddressRestaurants, navigate });
      setModalOpen(true);
    } else {
      navigate(`/${code}`);
    }
  };

  const closeModal = () => {
    setModalOpen(false);
    setModalContent(null);
  };
const scrollToContact = () => {
  const contactSection = document.getElementById("contact-us");
  if (contactSection) {
    contactSection.scrollIntoView({ behavior: "smooth" });
  }
};



  return (
    <Router>
      <Routes>
        <Route
          path="/"
          element={
            <div className="landing-page">
              {/* Landing page content starts here */}
              <div className="landing-page">
  {/* Hero Section */}
  <header className="header">
  <img src= {NB} loading="lazy" alt="Logo" className="logo" />
</header>
  <section className="hero-section">
    
    <div className="hero-content">
      
      <h1>Your Reliable Bus Timing Service</h1>
      <p>Get accurate bus timings, real-time updates, and never miss your bus again!</p>
      <button className="cta-button" onClick={scrollToContact}>Get Started</button>
    </div>
    <div className="hero-image">
      <img src={bus} loading="lazy" alt="Bus service" />
    </div>
  </section>

  {/* Features Section */}
  <section className="features-section">
    <h2>Why Choose Us?</h2>
    <div className="features">
      <div className="feature-card">
        <h3>Real-Time Updates</h3>
        <p>Stay informed with real-time bus arrivals and delays at every stop.</p>
      </div>
      <div className="feature-card">
        <h3>Easy to Use</h3>
        <p>Simply enter your destination and find the best bus options available.</p>
      </div>
      <div className="feature-card">
        <h3>Wide Coverage</h3>
        <p>Access bus timings from multiple routes across cities.</p>
      </div>
    </div>
  </section>

  {/* How It Works Section */}
  <section className="how-it-works-section">
    <h2>How It Works</h2>
    <div className="steps">
      <div className="step-card">
        <h3>1. Search for Your Route</h3>
        <p>Enter your starting point and destination to find the best bus routes available.</p>
      </div>
      <div className="step-card">
        <h3>2. View Real-Time Updates</h3>
        <p>Get accurate bus timings, including expected delays, and plan accordingly.</p>
      </div>
      
    </div>
  </section>

  {/* Testimonials Section */}
  <section className="testimonials-section">
    <h2>What Our Users Say</h2>
    <div className="testimonials">
      <div className="testimonial-card">
        <p>"Using this service has made my daily commute stress-free. I always know exactly when the bus will arrive!"</p>
        <span>- Priya Sharma</span>
      </div>
      <div className="testimonial-card">
        <p>"The real-time updates are so helpful. It’s accurate and makes sure I’m never waiting around for too long."</p>
        <span>- Ahmed Khan</span>
      </div>
      <div className="testimonial-card">
        <p>"Fantastic coverage of bus routes, even in remote areas. Highly recommend for anyone who relies on public transport."</p>
        <span>- Deepak Verma</span>
      </div>
    </div>
  </section>

  {/* FAQ Section */}
  <section className="faq-section">
    <h2>Frequently Asked Questions</h2>
    <div className="faqs">
      <div className="faq">
        <h3>How accurate are the bus timings?</h3>
        <p>Our bus timings are updated in real-time to ensure you receive the most accurate information available.</p>
      </div>
     
      <div className="faq">
        <h3>Is this service free?</h3>
        <p>Yes, the basic features are completely free for all users. Additional premium features may come at a cost in the future.</p>
      </div>
    </div>
  </section>

  {/* Call-to-Action Section */}
  {/* <section className="cta-section">
    <h2>Ready to Ride?</h2>
    <button className="cta-button">Find Your Bus</button>
  </section> */}

  {/* Contact Us Section */}
  <section id="contact-us" className="contact-us-section">
    <h2>Contact Us</h2>
    <p>If you have any questions or need support, feel free to reach out to us.</p>
   <form className="contact-form" action="https://formspree.io/f/xqazrqnq" method="POST">
  <input
    type="text"
    name="name"
    placeholder="Your Name"
    required
  />
  <input
    type="email"
    name="email"
    placeholder="Your Email"
    required
  />
  <textarea
    name="message"
    placeholder="Your Message"
    required
  ></textarea>
  <button type="submit" className="cta-button">Send Message</button>
</form>

  </section>
  
</div>

              
              <div className="search-div">
                {/* <input
                  type="text"
                  placeholder="Search Your Destination"
                  value={searchTerm}
                  onChange={handleSearch}
                  className="search-input"
                />
                <button onClick={performSearch} className="search-button">Search</button> */}
              </div>
              <div className="restaurant-grid">
                {/* {filteredRestaurants.map((restaurant, index) => (
                  <RestaurantCard
                    key={index}
                    image={restaurant.image}
                    address={restaurant.address}
                    vegnonveg={restaurant.vegnonveg}
                    rating={restaurant.rating}
                    ratingno={restaurant.ratingno}
                    code={restaurant.code}
                    room={restaurant.room}
                    onCardClick={handleCardClick}
                  />
                ))} */}
                
              </div>
              {/* Footer Section */}
<footer className="footer">
  <div className="footer-content">
    <p>&copy; 2024 Your Bus Service. All Rights Reserved.</p>
    {/* <div className="social-media">
      <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer">
        Facebook
      </a>
      <a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer">
        Twitter
      </a>
      <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer">
        Instagram
      </a>
      <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">
        LinkedIn
      </a>
    </div> */}
  </div>
</footer>

              
            </div>
          }
        />
        
        <Route path="/:code" element={<RestaurantMenu restaurants={restaurants} />} />
        <Route path="/sitemap" element={<Sitemap />} /> {/* Sitemap route */}
   
   <Route path="/google45611222a42f1812.html" element={<GoogleVerification />} />
      </Routes>
    </Router>
   
  );
};

const RestaurantMenu = ({ restaurants }) => {
  const { code } = useParams();
  const restaurant = restaurants.find((r) => r.code === code);

  if (!restaurant) {
    return <div></div>;
  }

  return (
    <div>
      <Helmet>
       <title>{restaurant.title} - Bus Timings and Route Details</title>
        <meta name="description" content={`Get accurate bus timings for ${restaurant.title}, with real-time updates and all the essential details you need for your journey.`} />
        <link rel="canonical" href={`https://nxt-bus.netlify.app/${code}`} />
      </Helmet>
   

      <MenuPage menu1={restaurant.menu1} />
    </div>
  );
};

export default App;
