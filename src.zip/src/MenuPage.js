import React, { useEffect, useState } from 'react';
import { LazyLoadImage } from 'react-lazy-load-image-component';
import 'react-lazy-load-image-component/src/effects/blur.css';
import NB from './NB.png';
import whatsappLogo from './whatsappLogo.png'; // Add your WhatsApp logo
import gmailLogo from './gmail.png'; // Add your Gmail logo
 // Import the Sitemap component
const MenuItem = ({ item, getTimeStatus }) => {
  return (
    <div className='section'>
      <article className="menu-item">
        <div className="child">
          {item.img && (
            <LazyLoadImage
              src={item.img}
              alt={item.title}
              className="photo"
            />
          )}
          <div className="item-info">
            <header>
              {item.title && <h4>{item.title}</h4>}
              <br />
              {item.time && (
                <h4 className="time">
                  {item.time}{' '}
                  <span className="time-status">
                    <span style={{ color: 'black' }}>(</span>
                    <span style={{ color: 'red' }}>{getTimeStatus(item.time)}</span>
                    <span style={{ color: 'black' }}>)</span>
                  </span>
                </h4>
              )}
            </header>
          </div>
        </div>
        {item.place && <div className="place">{item.place}</div>}
        {item.description && <div className="desc">[{item.description}]</div>}
      </article>
    </div>
  );
};

const MenuPage = ({ menu1 }) => {
  const [menuContent, setMenuContent] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedSubcategory, setSelectedSubcategory] = useState('');
  const [nextBus, setNextBus] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date()); // State for current time

 useEffect(() => {
  if (!menu1) {
    setMenuContent('Error');
    setLoading(false);
    return;
  }

  setLoading(true);
fetch(menu1)
  .then((response) => {
    if (!response.ok) {
      throw new Error('Failed to fetch');
    }
    return response.json();
  })
  .then((data) => {
    console.log(data); // Check the structure of the fetched data
    setMenuContent(data);
    setLoading(false);
    findNextBus(data);
  })
  .catch(() => {
    setMenuContent([]);
    setLoading(false);
  });


 const intervalId = setInterval(() => {
    if (Array.isArray(menuContent) && menuContent.length > 0) {
      findNextBus(menuContent); // Recalculate bus times every second
    }
  }, 1000); // Update every second

  return () => clearInterval(intervalId); // Cleanup on unmount
}, [menu1]);

 useEffect(() => {
    const timeInterval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timeInterval); // Cleanup on unmount
  }, []);

  const handleContextMenu = (e) => {
    e.preventDefault();
    const overlay = document.querySelector('.no-screenshot-overlay');
    if (overlay) overlay.classList.add('visible');
  };

  useEffect(() => {
    window.addEventListener('contextmenu', handleContextMenu);
    return () => {
      window.removeEventListener('contextmenu', handleContextMenu);
    };
  }, []);
  const getTimeStatus = (busTime, isTomorrow = false) => {
    if (!busTime) return '';

    const currentTimeForBus = new Date(currentTime); 
    const [time, modifier] = busTime.split(' ');
    let [busHours, busMinutes] = time.split(':').map(Number);

     if (modifier === 'PM' && busHours !== 12) {
      busHours += 12;
    }
    if (modifier === 'AM' && busHours === 12) {
      busHours = 0;
    }

    const busDate = new Date();
    if (isTomorrow) {
      busDate.setDate(busDate.getDate() + 1);
    }
    busDate.setHours(busHours, busMinutes, 0, 0);

    const remainingMs = busDate - currentTimeForBus;
    const remainingMinutes = Math.floor(remainingMs / 60000);

    if (remainingMinutes < 0) {
      return 'Passed';
    } else if (remainingMinutes <= 5) {
      return 'Will arrive soon';
    } else {
      const remainingHours = Math.floor(remainingMinutes / 60);
      const minutesLeft = remainingMinutes % 60;

      return remainingHours === 0 ? `${minutesLeft}m left` : `${remainingHours}h ${minutesLeft}m left`;
    }
  };

  const findNextBus = (menuContent) => {
    if (!menuContent || !Array.isArray(menuContent)) return; 
    const currentTimeForBus = new Date(currentTime);
    const upcomingBuses = menuContent.filter(item => {
      if (!item.time) return false;
      const [time, modifier] = item.time.split(' ');
      let [busHours, busMinutes] = time.split(':').map(Number);

      if (modifier === 'PM' && busHours !== 12) busHours += 12;
      if (modifier === 'AM' && busHours === 12) busHours = 0;

      const busDate = new Date();
      busDate.setHours(busHours, busMinutes, 0, 0);

      return busDate > currentTimeForBus; 
    });

    if (upcomingBuses.length > 0) {
      upcomingBuses.sort((a, b) => {
        const [aTime, aModifier] = a.time.split(' ');
        const [bTime, bModifier] = b.time.split(' ');

        const aHours = (aModifier === 'PM' && aTime.split(':')[0] !== '12') ? parseInt(aTime.split(':')[0]) + 12 : parseInt(aTime.split(':')[0]);
        const bHours = (bModifier === 'PM' && bTime.split(':')[0] !== '12') ? parseInt(bTime.split(':')[0]) + 12 : parseInt(bTime.split(':')[0]);

        return (aHours * 60 + parseInt(aTime.split(':')[1])) - (bHours * 60 + parseInt(bTime.split(':')[1]));
      });

      setNextBus(upcomingBuses[0]);
    } else {
      // If no buses left today, find the first bus for tomorrow
      const tomorrow = new Date(currentTimeForBus);
      tomorrow.setDate(tomorrow.getDate() + 1);

      const tomorrowBuses = menuContent.filter(item => {
        const [time, modifier] = item.time.split(' ');
        let [busHours, busMinutes] = time.split(':').map(Number);

        if (modifier === 'PM' && busHours !== 12) busHours += 12;
        if (modifier === 'AM' && busHours === 12) busHours = 0;

        const busDate = new Date(tomorrow);
        busDate.setHours(busHours, busMinutes, 0, 0);

        return busDate > currentTimeForBus;
      });

      if (tomorrowBuses.length > 0) {
        tomorrowBuses.sort((a, b) => {
          const [aTime, aModifier] = a.time.split(' ');
          const [bTime, bModifier] = b.time.split(' ');

          const aHours = (aModifier === 'PM' && aTime.split(':')[0] !== '12') ? parseInt(aTime.split(':')[0]) + 12 : parseInt(aTime.split(':')[0]);
          const bHours = (bModifier === 'PM' && bTime.split(':')[0] !== '12') ? parseInt(bTime.split(':')[0]) + 12 : parseInt(bTime.split(':')[0]);

          return (aHours * 60 + parseInt(aTime.split(':')[1])) - (bHours * 60 + parseInt(bTime.split(':')[1]));
        });

        // Set the next bus and mark it as tomorrow's bus
        setNextBus({ ...tomorrowBuses[0], isTomorrow: true });
      }
    }
  };

  const handleCategoryClick = (category) => {
    setSelectedCategory(category);
    setSelectedSubcategory('');
  };

  const handleSubcategoryClick = (subcategory) => {
    setSelectedSubcategory(subcategory);
  };

  const handleAllClick = () => {
    setSelectedCategory('');
    setSelectedSubcategory('');
  };
  const toggleModal = () => {
    setShowModal(!showModal);
  };



 if (loading) {
  return (
    <div className="wrap">
      <div className="spinner"></div><br />
      <h3>Please wait while your page is Loading</h3>
    </div>
  );
}


let filteredMenuContent = Array.isArray(menuContent) ? menuContent : [];

if (selectedCategory) {
  filteredMenuContent = filteredMenuContent.filter(
    (item) =>
      item.category === selectedCategory &&
      (!selectedSubcategory || item.subcategory === selectedSubcategory)
  );
}


  const categoryHeadings = {};

  if (!selectedCategory) {
    filteredMenuContent.forEach((menuItem) => {
      const category = menuItem.category;
      const subcategory = menuItem.subcategory;

      if (!categoryHeadings[category]) {
        categoryHeadings[category] = {};
      }

      if (!categoryHeadings[category][subcategory]) {
        categoryHeadings[category][subcategory] = [];
      }

      categoryHeadings[category][subcategory].push(menuItem);
    });
  }
if (selectedCategory) {
  filteredMenuContent = filteredMenuContent.filter(
    (item) =>
      item.category === selectedCategory &&
      (!selectedSubcategory || item.subcategory === selectedSubcategory)
  );
}

  return (
    <div>
       <div className="no-screenshot-overlay"></div>
       
      <div className="centered-container">
        {menuContent[0]?.logo && (
          <LazyLoadImage
            src={menuContent[0].logo}
            alt="Menu Logo"
            effect="blur"
            className="menu-logo"
          />
        )}
      </div>

      <div className="menu-container">
    

        <div className="filter-buttons">
          <button
            onClick={handleAllClick}
            className={!selectedCategory && !selectedSubcategory ? 'active' : ''}
          >
            All
          </button>
          {Array.from(new Set(menuContent.map((item) => item.category))).map(
            (category, index) => (
              <button
                key={index}
                onClick={() => handleCategoryClick(category)}
                className={category === selectedCategory ? 'active' : ''}
              >
                {category}
              </button>
            )
          )}
        </div>

        {selectedCategory && (
          <div className="subcategory-buttons">
            {Array.from(
              new Set(
                menuContent
                  .filter((item) => item.category === selectedCategory && item.subcategory)
                  .map((item) => item.subcategory)
              )
            ).map((subcategory, index) => (
              <button
                key={index}
                onClick={() => handleSubcategoryClick(subcategory)}
                className={subcategory === selectedSubcategory ? 'active' : ''}
              >
                {subcategory}
              </button>
            ))}
          </div>
        )}

        <div className="menu-items-container">
          {selectedCategory
            ? filteredMenuContent.map((menuItem, index) => (
                <div key={index}>
            <MenuItem item={menuItem} getTimeStatus={getTimeStatus} />
           
          </div>
              ))
            : Object.entries(categoryHeadings).map(([category, subcategories], index) => (
                <div key={index}>
                  {category && <h3 className="heading">{category}</h3>}
                  {Object.entries(subcategories).map(([subcategory, items], subIndex) => (
                    <div key={subIndex}>
                      {subcategory && <h4 className="subheading">{subcategory}</h4>}
                      {items.map((menuitem, itemIndex) => (
                        <MenuItem key={itemIndex} item={menuitem} getTimeStatus={getTimeStatus} />
                      ))}
                    </div>
                  ))}
                </div>
              ))}
        </div>

      {nextBus && (
  <footer className="footer1">
    <div className="next-bus-info">
      <p className='next-time'>
        <b>Next Bus: </b> {nextBus.title}{' '}
        <b>
          (<span style={{ color: 'red' }}>
            {getTimeStatus(nextBus.time, nextBus.isTomorrow)}
          </span>)
        </b>
      </p>
    </div>
  </footer>
  
)}
 <section id="contact-us" className="contact-us-section">
    <h2>Contact Us</h2>
    <p>If you have any questions or need support, feel free to reach out to us.</p>
   <form className="contact-form" action="https://formspree.io/f/xqazrqnq" method="POST">
  <input
    type="text"
    name="name"
    placeholder="Your Name"
    required
  />
  <input
    type="email"
    name="email"
    placeholder="Your Email"
    required
  />
  <textarea
    name="message"
    placeholder="Your Message"
    required
  ></textarea>
  <button type="submit" className="cta-button">Send Message</button>
</form>

  </section>
  
{showModal && ( // Show modal only when showModal is true
        <div className="modal-overlay">
          <div className="modal-content">
            <h4>CONTACT US</h4>
            <p>For any inquiries or feedback, please feel free to contact us via WhatsApp or email in the below:</p>
            
            <div className="inquiry-icons">
              <a href="https://wa.me/+916364039135" target="_blank" rel="noopener noreferrer">
                <LazyLoadImage src={whatsappLogo} alt="WhatsApp" className="contact-icon" />
              </a>
              <a href="mailto:nxtbus.aman@gmail.com">
                <LazyLoadImage src={gmailLogo} alt="Gmail" className="contact-icon" />
              </a>
            </div>
            
            <button className="close-modal" onClick={toggleModal}>Close</button>
          </div>
        </div>
      )}
 <div className="fixed-image">
      <img src={NB} alt="Fixed Image" onClick={toggleModal}  />
    </div>
      </div>
    </div>
  );
};

export default MenuPage;
