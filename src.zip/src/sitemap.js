// src/components/Sitemap.js

import React, { useEffect, useState } from 'react';

const SHEET_URL = 'https://opensheet.elk.sh/1tj1hdKsm3B_Yv9dAIHBNUqAxEtdVmUNfNVN-YT-9VRE/Sheet1!A1:Z99999';

const Sitemap = () => {
  const [xmlContent, setXmlContent] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(SHEET_URL);
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }
        const sheetData = await response.json();

        let sitemapXML = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n`;
        sheetData.forEach((item) => {
          sitemapXML += `  <url>\n    <loc>https://nxt-bus.netlify.app/${item.code}</loc>\n  </url>\n`;
        });
        sitemapXML += `</urlset>`;

        setXmlContent(sitemapXML);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching data:', err);
        setError(true);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) return <div>Loading sitemap data...</div>;
  if (error) return <div>Failed to load sitemap data. Please try again later.</div>;

  // Serve XML content
  return (
    <div>
      <h2>Sitemap</h2>
      <pre style={{ whiteSpace: 'pre-wrap', wordWrap: 'break-word' }}>
        {xmlContent}
      </pre>
    </div>
  );
};

export default Sitemap;
