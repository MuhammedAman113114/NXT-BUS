// GoogleVerification.js
import React from 'react';

const GoogleVerification = () => {
    return (
        <div>
            <p>google-site-verification: google45611222a42f1812.html</p>
        </div>
    );
};

export default GoogleVerification;
