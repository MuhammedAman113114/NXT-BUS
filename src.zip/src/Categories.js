import React from "react";

const Categories = ({ categories, filterItems, activeCategory }) => {
  return (
    <div className="scroll-navbar">
      <div className="btn-container">
     
    </div>
    </div>
  );
};

export default Categories;

